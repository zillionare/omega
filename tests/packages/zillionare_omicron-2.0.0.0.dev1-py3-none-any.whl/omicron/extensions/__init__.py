from omicron.extensions.np import *
