"""
与数据服务器(omega)的接口。

Omega通过http提供数据服务。数据以pickle格式通过http content返回。本module实现了http接口的封装
和数据的解码。
"""