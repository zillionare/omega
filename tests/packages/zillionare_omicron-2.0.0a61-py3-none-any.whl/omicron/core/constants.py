TRADE_PRICE_LIMITS = "trade_price_limits"
TRADE_PRICE_LIMITS_DATE = "trade_price_limits:date"

TRADE_LATEST_PRICE = "security:latest_price"
