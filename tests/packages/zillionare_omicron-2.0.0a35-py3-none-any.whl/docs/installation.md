
# 1. 安装

要使用Omicron来获取行情数据，请先安装[Omega](https://pypi.org/project/zillionare-omega/)，并按说明文档要求完成初始化配置。

然后在开发机上，运行下面的命令安装Omicron:

``` bash
    pip install zillionare-omicron
```

如果您是大富翁项目的协同开发者，请参见 [大富翁开发指南](https://zillionare.readthedocs.io/zh_CN/latest/developer_guide.html)来构建开发环境。
